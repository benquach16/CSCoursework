#ifndef _TRIANGLE_H_
#define _TRIANGLE_H_

class Triangle
{

};

#endif
